require("dotenv").config()

require("./payment/app.js");
require("./discord/bot.js")